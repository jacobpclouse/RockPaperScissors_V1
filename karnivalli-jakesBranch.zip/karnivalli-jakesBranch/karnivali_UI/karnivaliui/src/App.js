
import './App.css';
import RPSGameScreen from './RockPaperScissorJake/RPKGameScreenJake';
// import Welcome from './WelcomePage/welcomeBox';
// import StartBtn from './WelcomePage/clickStartBox';
import RPSJake from './RockPaperScissorJake/RPKGameScreenJake.js';

function App() {
  return (
    <div>
      <RPSGameScreen/>
      {/* <Welcome /> */}
      
      {/* <StartBtn /> */}
      
    </div>


  );
}

export default App;
